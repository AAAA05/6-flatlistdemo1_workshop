import react from 'react';
//import ColumnItem from './column-item';//
import LayOut from './layout';
import LayOut2 from './layout2';
import Question from './Question';
import ButtonDemo from './button-demo';

export default function App() {
  return (
      //<ColumnItem/>//
      //<RowItem/>//
     //<Question/>//
     <ButtonDemo/>
     
      
  );
}
